<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
  session_start();
  function truncate($text, $chars) {    
    if (strlen($text) <= $chars) return $text;
    $text = $text." ";
    $text = substr($text,0,$chars);
    $text = substr($text,0,strrpos($text,' '));
    $text = $text."...";
    return $text;
 }
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Көкжиек</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<script type="text/javascript" src="js/jquery-2.0.3.js"></script>
</head>
<body>
<div id="wrap">

       <div class="header">
            <div class="logo"><a href="index.php"><img src="images/evo.png" style="height:50px; float:left;" alt="" title="" border="0" style="height:40px" /></a></div>            
        <div id="menu">
            <ul>                                                                       
            <li><a href="index.php">Главная</a></li>            
            <li><a href="category.php">Магазин</a></li>
            <li><a href="blog.php">Отзывы</a></li>
            <li><a href="about.php">О нас</a></li>
            <li><a href="contact.php">Контакты</a></li>
            </ul>
        </div>     
        <div id="regbar">
          <ul>
          <?php          
          if ($_SESSION["Login"] != "NO" AND $_SESSION["Login"] != "admin" AND $_SESSION["Login"] == "na") {
            echo "<li><a href='mysettings.php'>Профиль</a></li>";
            echo "<li><a href='logout.php'>ВЫход</a></li>";
          } else if ($_SESSION["Login"] == "admin") {
            echo "<li><a href='admin.php'>Профиль</a></li>";
            echo "<li><a href='logout.php'>Выход</a></li>";
          } else {
            echo "<li><a href='myaccount.php'>Вход</a></li>";
            echo "<li><a href='register.php'>Регистрация</a></li>";
          }
          ?>           
          
          </ul>  
        </div>
        <div id="div_search">
          <form method="get" action="search.php" id="search">
            <input name="search" type="text" size="40" placeholder="Поиск..." />
          </form>
        </div>    
            
       </div> 
       
       
       <div class="center_content">
       	<div class="left_content">
        	
            <div class="title"><span class="title_icon"><img src="images/bullet1.png" alt="" title="" /></span>Магазин</div>
            <?php                  
                  $con=mysqli_connect("localhost","root","","bookstore");
                  // Check connection
                  if (mysqli_connect_errno())
                    {
                      echo "Failed to connect to MySQL: " . mysqli_connect_error();
                    }
                  mysql_set_charset('utf8');
                  $count = 0;
                  $break = 0;
                  $paginator = 0;
                  $search = "***non";
                  $category = "***non";
                  $result = "";
                  if (!empty($_GET['pos'])) {
                        $paginator = $_GET['pos'] * 3;
                  } 
                  if (!empty($_GET['category'])) {
                    $category = $_GET['category'];
                    if ($category != '***non')
                      $result = mysqli_query($con,"SELECT * FROM book WHERE category LIKE '%".$_GET['category']."%'");  
                  }
                   else 
                    if (!empty($_GET['search'])){
                      $search = $_GET['search'];
                      if ($search != '***non')
                        $result = mysqli_query($con,"SELECT * FROM book WHERE category LIKE '%".$_GET['search']."%' OR name LIKE '%".$_GET['search']."%' OR year LIKE '%".$_GET['search']."%' OR author LIKE '%".$_GET['search']."%' OR price LIKE '%".$_GET['search']."%'");  else $result = mysqli_query($con,"SELECT * FROM book");  
                    }
                  if ($result == "") $result = mysqli_query($con,"SELECT * FROM book WHERE id=1");  
                  
                  while($row = mysqli_fetch_array($result))
                  { 
     
                    if ($count >= $paginator && $break < 3){
                      echo "<div class='feat_prod_box'>";
                      echo "<div class='prod_img'><a href='details.php?id=".$row['id']."'><img src=images/".$row['pic']."  border='0' style='height:150px; width:100px;' /></a></div>";
                      echo "<div class='prod_det_box'>";
                      echo "<div class='box_top'></div>";
                      echo "<div class='box_center'>";
                      echo "<div class='prod_title'>".$row['name']."</div>";
                      echo "<p class='details'>".truncate($row['details'] , 300)."</p>";
                      echo "<a href='details.php?id=".$row['id']."' class='more'></a>";
                      echo "<div class='clear'></div>";
                      echo "</div>";                      
                      echo "<div class='box_bottom'></div>";
                      echo "</div>";
                      echo "<div class='clear'></div>";
                      echo "</div>";
                      $break++;
                    }                        
                    $count++;
                  }
                    $paginator = $paginator / 3;                    
                    echo "<div class='pagination'>";
                    if ($paginator == 0) echo "<span class='disabled'><<</span>"; else echo "<a href='?category=".$category."&search=".$search."&pos=0'><<</a>";
                    for ($i = 0; $i < ceil($count / 3); $i++) {
                      if ($i == $paginator) echo "<span class='current'>".($i + 1)."</span>";
                      else {
                        echo "<a href='?category=".$category."&search=".$search."&pos=".$i."'>".($i + 1)."</a>";
                      }
                    }
                    if ($count == 0) {
                      echo "<span class='disabled'>>></span>";
                    } else
                    if ($paginator + 1 != ceil($count / 3)) echo "<a href='?category=".$category."&search=".$search."&pos=".(ceil($count / 3) - 1)."'>>></a>"; else echo "<span class='disabled'>>></span>";
                   //echo "<a href='?pos=2'>2</a><a href='?pos=3'>3</a>…<a href='?pos=199'>10</a><a href='?pos=200'>11</a><a href='?pos=2'>>></a>";
                    echo "</div>";
                    mysql_close();
            ?>
        <div class="clear"></div>
        </div><!--end of left content-->
        
        <div class="right_content">                
 <?php       
          if ($_SESSION["Login"] != "NO" AND $_SESSION["Login"] != "admin") {
              $result = mysqli_query($con,"SELECT cart,total FROM user WHERE id=" .$_SESSION['Login']);
              $cart = "";
              $total = 0;
              $length = 0;
              while($row = mysqli_fetch_array($result))
              {
                $cart = $row['cart'];
                $total = $row['total'];
              }
              $cartar = split("&",$cart);              
              if (sizeof($cartar) <= 1) $length = 0; else $length = sizeof($cartar) - 1;
              echo "<div class='cart'>";
              echo "<div class='title'><span class='title_icon'><img src='images/cart.gif' /></span>Корзина</div>";
              echo "<div class='home_cart_content'>";
              echo $length." x  товар | <span class='red'>Все: ".$total."$</span>";
              echo "</div>";
              echo "<a href='cart.php' class='view_cart'>Посмотреть корзину</a>";
              echo "</div>";
          }  
        ?>            
        
        
             <div class="title"><span class="title_icon"><img src="images/bullet3.gif" alt="" title="" /></span>О компании</div> 
             <div class="about">
             <p>
             <img src="images/evo.png" style="height:65px; width:225px;" alt="" title="" class="right" />
              Компания была основана в 2016 при поддержки футбольного клуба «Evolution». Цель компании является расширенность по всему миру, и сделать себе настоящее имя.
             </p>
             
             </div>
         
             
            <div class="right_box">
             
              <div class="title"><span class="title_icon"><img src="images/bullet5.gif" alt="" title="" /></span>Категории</div> 
                
                <ul class="list">
                <?php 
                  $result = mysqli_query($con,"SELECT DISTINCT category FROM book");
                  while($row = mysqli_fetch_array($result))
                  {
                    echo "<li><a href='search.php?category=".$row['category']."'>".$row['category']."</a></li>";
                  }
                ?>                
                </ul>
             
             </div>
     
        
        </div><!--end of right content-->
        
        
       
       
       <div class="clear"></div>
       </div><!--end of center content-->
       
       

</div>

</body>
</html>