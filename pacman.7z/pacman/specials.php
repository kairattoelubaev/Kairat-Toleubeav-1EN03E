<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
  session_start();
    function truncate($text, $chars) {    
    if (strlen($text) <= $chars) return $text;
    $text = $text." ";
    $text = substr($text,0,$chars);
    $text = substr($text,0,strrpos($text,' '));
    $text = $text."...";
    return $text;
 }
?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Book Store</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
<div id="wrap">

       <div class="header">
            <div class="logo"><a href="index.php"><img src="images/logo.png" alt="" title="" border="0" style="height:40px" /></a></div>            
        <div id="menu">
            <ul>                                                                       
            <li><a href="index.php">Басқы бет</a></li>            
            <li><a href="category.php">Кітаптар</a></li>
            <li class="selected"><a href="specials.php">Ерекше кітаптар</a></li>
            <li><a href="about.php">Біз туралы</a></li>
            <li><a href="contact.php">Хабарласу</a></li>            
            </ul>
        </div>     
        <div id="regbar">
          <ul>
          <?php          
          if ($_SESSION["Login"] != "NO" AND $_SESSION["Login"] != "admin") {
            echo "<li><a href='mysettings.php'>Профиль</a></li>";
            echo "<li><a href='logout.php'>Шығу</a></li>";
          } else if ($_SESSION["Login"] == "admin") {
            echo "<li><a href='admin.php'>Профиль</a></li>";
            echo "<li><a href='logout.php'>Шығу</a></li>";
          } else {
            echo "<li><a href='myaccount.php'>Кіру</a></li>";
            echo "<li><a href='register.php'>Тіркелу</a></li>";
          }
          ?>  
          </ul>  
        </div>
        <div id="div_search">
          <form method="get" action="search.php" id="search">
            <input name="search" type="text" size="40" placeholder="Іздеу..." />
          </form>
        </div>    
            
       </div> 
       
       
       <div class="center_content">
       	<div class="left_content">
        	
            <div class="title"><span class="title_icon"><img src="images/bullet1.png" alt="" title="" /></span>Ерекше кітаптар</div>
        
        	<?php                  
                  $con=mysqli_connect("localhost","root","","bookstore");
                  // Check connection
                  if (mysqli_connect_errno())
                    {
                      echo "Failed to connect to MySQL: " . mysqli_connect_error();
                    }
                  $count = 0;
                  $break = 0;
                  $paginator = 0;
                  if (!empty($_GET['pos'])) {
                        $paginator = $_GET['pos'] * 3;
                  } 
                  $result = mysqli_query($con,"SELECT * FROM book");
                  while($row = mysqli_fetch_array($result))
                  { 
                    if ( $row['status'] == "special"){
                    if ($count >= $paginator && $break < 3){
                      echo "<div class='feat_prod_box'>";
                      echo "<div class='prod_img'><a href='details.php?id=".$row['id']."'><img src=uploads/".$row['pic']."  border='0' style='height:150px; width:100px;' /></a></div>";
                      echo "<div class='prod_det_box'>";
                      
                        echo "<span class='special_icon'><img src='images/special_icon.gif'></span>";
                        echo "<div class='box_top'></div>";
                        echo "<div class='box_center'>";
                        echo "<div class='prod_title'>".$row['name']."</div>";
                        echo "<p class='details'>".truncate($row['details'] , 300)."</p>";
                        echo "<a href='details.php?id=".$row['id']."' class='more'>- қосымша -</a>";
                        echo "<div class='clear'></div>";
                        echo "</div>";
                        
                        echo "<div class='box_bottom'></div>";
                        echo "</div>";
                        echo "<div class='clear'></div>";
                        echo "</div>";
                        $break++;
                    }                        
                    $count++;
                  }
                  }
                    $paginator = $paginator / 3;                    
                    echo "<div class='pagination'>";
                    if ($paginator == 0) echo "<span class='disabled'><<</span>"; else echo "<a href='?pos=0'><<</a>";
                    if ($count > 3){
                    for ($i = 0; $i < ceil($count / 3); $i++) {
                      if ($i == $paginator) echo "<span class='current'>".($i + 1)."</span>";
                      else {
                        echo "<a href='?pos=".$i."'>".($i + 1)."</a>";
                      }
                    } }else { echo "<span class='current'>1</span><span class='disabled'>>></span>"; } 
                    if ($paginator + 1 != ceil($count / 3) && $count > 3) echo "<a href='?pos=".(ceil($count / 3) - 1)."'>>></a>"; else echo "<span class='disabled'>>></span>";
                   echo "<a href='?pos=2'>2</a><a href='?pos=3'>3</a>…<a href='?pos=199'>10</a><a href='?pos=200'>11</a><a href='?pos=2'>>></a>";
                    echo "</div>";

            ?>
        </div><!--end of left content-->
        
        <div class="right_content">
        	    
         <?php       
          if ($_SESSION["Login"] != "NO" AND $_SESSION["Login"] != "admin") {
              $result = mysqli_query($con,"SELECT cart,total FROM user WHERE id=" .$_SESSION['Login']);
              $cart = "";
              $total = 0;
              $length = 0;
              while($row = mysqli_fetch_array($result))
              {
                $cart = $row['cart'];
                $total = $row['total'];
              }
              $cartar = split("&",$cart);              
              if (sizeof($cartar) <= 1) $length = 0; else $length = sizeof($cartar) - 1;
              echo "<div class='cart'>";
              echo "<div class='title'><span class='title_icon'><img src='images/cart.gif' /></span>Себет</div>";
              echo "<div class='home_cart_content'>";
              echo $length." x кітап | <span class='red'>Барлығы: ".$total."$</span>";
              echo "</div>";
              echo "<a href='cart.php' class='view_cart'>себетті көру</a>";
              echo "</div>";
          }             
        ?>            
        
        
             <div class="title"><span class="title_icon"><img src="images/bullet3.gif" alt="" title="" /></span>Біздің дүкен туралы</div> 
             <div class="about">
             <p>
             <img src="images/about.gif" alt="" title="" class="right" />
              Баспа ұжымы қысқа уақыт аралығында діни-танымдық және рухани-мәдени тақырыптағы мазмұнды еңбектерімен республикаға танылып, осы саладағы еліміздің жетекші баспаларының бірі болып үлгерді. 
             </p>
             
             </div>
         
             
            <div class="right_box">
             
              <div class="title"><span class="title_icon"><img src="images/bullet5.gif" alt="" title="" /></span>Категориялар</div> 
                
                <ul class="list">
                <?php 
                  $result = mysqli_query($con,"SELECT DISTINCT category FROM book");
                  while($row = mysqli_fetch_array($result))
                  {
                    echo "<li><a href='search.php?category=".$row['category']."'>".$row['category']."</a></li>";
                  }
                ?>                
                </ul>
             
             </div>
     
        
        </div><!--end of right content-->
        
        
       
       
       <div class="clear"></div>
       </div><!--end of center content-->
       
              
       <div class="footer">
        
                <div class="right_footer">
         <strong>Адрес: </strong> Мақатаев көшесі, 128А үй, Алматы қаласы,050004<br /> 
<strong>Е-пошта:</strong> akkuanov.salamat@gmail.com<br  />
<strong>Телефон:</strong> +7 702 999 50 27
            </div>
       
       </div>
    

</div>

</body>
</html>