<?php
  $con=mysqli_connect("localhost","root","","bookstore");
  // Check connection
  if (mysqli_connect_errno()){
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
    $name = "";
    $author = "";
    $page = "";
    $year = "";
    $category = "";
    $pic = "";
    $details = "";
    $price = "";
    $status = "";
    $sql = "SELECT * FROM book WHERE id=".$_POST['id'];
    $result = mysqli_query($con,$sql);
    while($row = mysqli_fetch_array($result))
    {         
        $name = $row['name'];
        $author = $row['author'];
        $page = $row['page'];
        $year = $row['year'];
        $category = $row['category'];
        $pic = $row['pic'];
        $details = $row['details'];
        $price = $row['price'];
        $status = $row['status'];
      }
    if (!mysqli_query($con,$sql)){
      die('Error: ' . mysqli_error($con));
  }
  echo($name."|".$author."|".$page."|".$year."|".$category."|".$pic."|".$details."|".$price."|".$status);
  mysqli_close($con);
  //header("Location:admin.php")
?>
