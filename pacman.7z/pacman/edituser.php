<?php
    $con=mysqli_connect("localhost","root","","bookstore");
    // Check connection
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }                    
    
    mysql_set_charset('utf8');
    if (strlen($_POST['password']) > 1)
      $sql = "UPDATE user SET name='".$_POST['name']."',password='".$_POST['password']."',email='".$_POST['email']."',phone='".$_POST['phone']."',address='".$_POST['address']."' WHERE id=".$_POST['ide']; 
    else
      $sql = "UPDATE user SET name='".$_POST['name']."',email='".$_POST['email']."',phone='".$_POST['phone']."',address='".$_POST['address']."' WHERE id=".$_POST['ide']; 
    if (!mysqli_query($con,$sql)){
        die('Error: ' . mysqli_error($con));
    }
    mysqli_close($con);            
    header( 'Location: mysettings.php' ) ;
?>