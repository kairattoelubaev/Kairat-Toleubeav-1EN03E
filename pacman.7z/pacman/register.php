<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php 
$con=mysqli_connect("localhost","root","","bookstore");
// Check connection
if (mysqli_connect_errno())
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
mysql_set_charset('utf8');
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>REGISTRATION | EVOLUTION</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<script type="text/javascript" src="js/jquery-2.0.3.js"></script>
<script>
$(document).ready(function() { 
  $("#register").click(function(){                                       
         $('#myform').delay(2000).trigger('submit');
      });
});
</script>

</head>
<body>
<div id="wrap">

       <div class="header">
           <div class="logo"><a href="index.php"><img src="images/home/evo.png" alt="" title="" border="0" style="height:40px" /></a></div>  

        <div id="menu">
            <ul>                                                                              
            <li class="selected"><a href="index.php">Главная</a></li>                        
            <span class="divider"></span>
            <li><a href="category.php">Магазин</a></li>
            <span class="divider"></span>
            <li><a href="blog.php">Отзывы</a></li>
            <span class="divider"></span>
            <li><a href="about.php">О нас</a></li>
            <span class="divider"></span>
            <li><a href="contact.php">Контакты</a></li>
            <span class="divider"></span>
            </ul>
            <div id="div_search">
          <form method="get">
            <input name="search" type="text" size="20" style="margin-left:700px; margin-top:-80px;" placeholder="Поиск..." />
          </form></div>
        </div>
            <div id="regbar" style="margin-left: 450px; margin-top:-15px;">
          <ul>
            <li><a href="myaccount.php">Вход</a></li>
            <li class="selected"><a href="register.php">Регистрация</a></li>
          </ul>  
        </div>
                  
            
       </div> 
       
       
       <div class="center_content">
       	<div class="left_content">
        
        	<div class="feat_prod_box_details">
            
              	<div class="contact_form">
                <div class="form_subtitle">Форма заполнение</div>
                 <form name="register" action="registerme.php" method="post" id="myform">          
                    <div class="form_row">
                    <label class="contact"><strong>Имя:</strong></label>
                    <input type="text" class="contact_input" name="name" onkeypress="register" />
                    </div>  


                    <div class="form_row">
                    <label class="contact"><strong>Пароль:</strong></label>
                    <input type="password" class="contact_input" name="password" />
                    </div> 

                    <div class="form_row">
                    <label class="contact"><strong>Э-почта:</strong></label>
                    <input type="text" class="contact_input" name="email" />
                    </div>


                    <div class="form_row">
                    <label class="contact"><strong>Телефон:</strong></label>
                    <input type="text" class="contact_input" name="phone" />
                    </div>
                                        
                    <div class="form_row">
                    <label class="contact"><strong>Адресс:</strong></label>
                    <input type="text" class="contact_input" name="address" />
                    </div>                    
                    
                    <a href="#" id="register" class="button button-brown" style="margin-left:170px">
                        <span>Регистрация</span>
                    </a>                                                       
                    <input type="submit" class="register" value="register" style="display:none"  />
                    
                  </form>     
                </div>  
            
          </div>	
            
              

            

            
        <div class="clear"></div>
        </div><!--end of left content-->
        
        <div class="right_content">
                
             <div class="title"><span class="title_icon"><img src="images/bullet3.gif" alt="" title="" /></span>О компании</div> 
             <div class="about">
             <p>
             <img src="images/evo.png" style="height:65px; width:225px;" alt="" title="" class="right" />
              Компания была основана в 2016 при поддержки футбольного клуба «Evolution». Цель компании является расширенность по всему миру, и сделать себе настоящее имя.
              
             </p>
             
             </div>
             
             <div class="right_box">
             
              <div class="title"><span class="title_icon"><img src="images/bullet5.gif" alt="" title="" /></span>Категории</div> 
                
                <ul class="list">
                <?php 
                  $result = mysqli_query($con,"SELECT DISTINCT category FROM book");
                  while($row = mysqli_fetch_array($result))
                  {
                    echo "<li><a href='search.php?category=".$row['category']."'>".$row['category']."</a></li>";
                  }
                ?>                
                </ul>
             
             </div>
     
        
        </div><!--end of right content-->
        
        
       
       
       <div class="clear"></div>
       </div><!--end of center content-->
       
              
       <div class="footer">
        
<div class="footer">
        ©Copyright Все права защищены <a href = "index.php">Kairat Toleubaev</a>
       </div>
    

</div>

</body>
</html>