<?php
  $allowedExts = array("gif", "jpeg", "jpg", "png");
  $temp = explode(".", $_FILES["file"]["name"]);
  $extension = end($temp);
    if ((($_FILES["file"]["type"] == "image/gif")
      || ($_FILES["file"]["type"] == "image/jpeg")
      || ($_FILES["file"]["type"] == "image/jpg")
      || ($_FILES["file"]["type"] == "image/pjpeg")
      || ($_FILES["file"]["type"] == "image/x-png")
      || ($_FILES["file"]["type"] == "image/png"))
      && ($_FILES["file"]["size"] < 200000)
      && in_array($extension, $allowedExts))
        {
          if ($_FILES["file"]["error"] > 0)
            {
              echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
            }
            else
              {
                echo "Upload: " . $_FILES["file"]["name"] . "<br>";
                echo "Type: " . $_FILES["file"]["type"] . "<br>";
                echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
                echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br>";

                if (file_exists("uploads/" . $_FILES["file"]["name"]))
                  {
                    echo $_FILES["file"]["name"] . " already exists. ";
                  }
                else
                  {
                    move_uploaded_file($_FILES["file"]["tmp_name"],
                    "uploads/" . $_FILES["file"]["name"]);
                    echo "Stored in: " . "upload/" . $_FILES["file"]["name"] ."<br>";
                    //SQL CONNECTION                    
                    $con=mysqli_connect("localhost","root","","bookstore");
                    // Check connection
                    if (mysqli_connect_errno()){
                        echo "Failed to connect to MySQL: " . mysqli_connect_error();
                      }                    
                    unlink("uploads/".$_POST['img']);
                    mysql_set_charset('utf8');
                    $sql = "UPDATE book SET name='".$_POST['name']."',author='".$_POST['author']."',page='".$_POST['page']."',year='".$_POST['year']."',category='".$_POST['category']."',pic='".$_FILES['file']['name']."',details='".$_POST['details']."',price='".$_POST['price']."',status='".$_POST['status']."' WHERE id=".$_POST['ide'];
                    if (!mysqli_query($con,$sql)){
                        die('Error: ' . mysqli_error($con));
                    }
                    mysqli_close($con);            
                  }
               }
        }
    else
    {
      echo "Invalid file";
    }
    header( 'Location: admin.php?pos='.($_POST['pos'] - 1) ) ;
?>