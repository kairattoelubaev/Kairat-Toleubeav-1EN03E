<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
  session_start();
  $con=mysqli_connect("localhost","root","","bookstore");
  // Check connection
  if (mysqli_connect_errno())
    {
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
  mysql_set_charset('utf8');
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf8" />
<title>EVOLUTION</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<script type="text/javascript" src="js/jquery-2.0.3.js"></script>
<script>
  function del(id){
       $("#idd").val(id);                                                          
       $('#myform1').trigger('submit');
   }

</script>
</head>
<body>
<div id="wrap">

       <div class="header">
          <div class="logo"><a href="index.php"><img src="images/evo.png" style="height:65px; width:200px; margin-top:-25px;" alt="" title="" border="0" style="height:40px" /></a></div>            
        <div id="menu">
            <ul>                                                                       
            <li><a href="index.php">Главная</a></li>            
            <li><a href="category.php">Товары</a></li>
            <li><a href="blog.php">Отзывы</a></li>
            <li><a href="about.php">О нас</a></li>
            <li><a href="contact.php">Контакты</a></li>
            </ul>
        </div>     
        <div id="regbar">
          <ul>
          <?php          
          if ($_SESSION["Login"] != "NO" AND $_SESSION["Login"] != "admin") {
            echo "<li><a href='mysettings.php'>Профиль</a></li>";
            echo "<li><a href='logout.php'>Выход</a></li>";
          } else {
            echo "<li><a href='myaccount.php'>Вход</a></li>";
            echo "<li><a href='register.php'>Регистрация</a></li>";
          }
          ?>  
          </ul>  
        </div>
        <div id="div_search">
          <form method="get" action="search.php" id="search">
            <input name="search" type="text" size="40" placeholder="Поиск..." />
          </form>
        </div>            
            
       </div> 
       
       
       <div class="center_content">
       	<div class="left_content">
            <div class="title"><span class="title_icon"><img src="images/bullet1.png" alt="" title="" /></span>Моя корзина</div>
        
        	<div class="feat_prod_box_details">
            
            <table class="cart_table">
            	<tr class="cart_title">
                  <td>Удалить</td>
                	<td>Вид</td>
                	<td>Название</td>
                  <td>Цена</td>                                         
                </tr>
                <?php                  
                 
                  $result = mysqli_query($con,"SELECT cart,total FROM user");
                  $cart = "";
                  $total = 0;
                  $count = 0;
                  while($row = mysqli_fetch_array($result))
                  {
                      $cart = $row['cart'];
                   $total = $row['total'];                     
                  }
                  $array = split("&",$cart);
                  $arrayi = [];
                  $arrayc = [];
                  $arrayp = [];
                  for ($i = 1; $i < sizeof($array); $i++){
                    $result = mysqli_query($con,"SELECT name,price FROM book WHERE id=".$array[$i]);
                    while($row = mysqli_fetch_array($result))
                    {
                      
                      array_push($arrayc, $row['name']);
                      array_push($arrayp, $row['price']);
                    } 
                  }
                  for ($i=0; $i < sizeof($array) - 1; $i++) { 
                    echo "<tr>";
                    echo "<td><input type='button' class='delete_cart' onClick=del(".$array[$i + 1].")></td>";
                    echo "<td><a href='details.php?id=".$array[$i + 1]."'><img src='images/".$arrayi[$i]."' class='cart_thumb' style='width:29px; height:41px;' /></a></td>";
                    echo "<td>".$arrayc[$i]."</td> <td>".$arrayp[$i]." $</td></tr>";      
                  }                                     
                    
                ?>               
                
                <tr>
                <td colspan="3" class="cart_total"><span class="red">Все:</span></td>
                <td><?php echo $total." $";?></td>                
                </tr>                  
            
            </table>
            <a href="homebank.kz" class="button button-brown" style="margin-left:300px">
              <span>Купить</span>
            </a>   
            
            </div>	
           <form action="deletecart.php" method="post" id="myform1">              
            <input type="text" name="idd" id="idd" style="display:none">
            <input type="submit" action="deletecart.php" value="delete" style="display:none">              
          </form>  
        <div class="clear"></div>
        </div><!--end of left content-->
        
        <div class="right_content">                
 <?php       
          if ($_SESSION["Login"] != "NO" AND $_SESSION["Login"] != "admin") {
              $result = mysqli_query($con,"SELECT cart,total FROM user WHERE id=" .$_SESSION['Login']);
              $cart = "";
              $total = 0;
              $length = 0;
              while($row = mysqli_fetch_array($result))
              {
                $cart = $row['cart'];
                $total = $row['total'];
              }
              $cartar = split("&",$cart);              
              if (sizeof($cartar) <= 1) $length = 0; else $length = sizeof($cartar) - 1;
              echo "<div class='cart'>";
              echo "<div class='title'><span class='title_icon'><img src='images/cart.gif' /></span>Корзина</div>";
              echo "<div class='home_cart_content'>";
              echo $length." x товар | <span class='red'>Все: ".$total."$</span>";
              echo "</div>";
              echo "<a href='cart.php' class='view_cart'>Посмотреть корзину</a>";
              echo "</div>";
          }             
        ?>            
        
        
             <div class="title"><span class="title_icon"><img src="images/bullet3.gif" alt="" title="" /></span>О компании</div> 
             <div class="about">
             <p>
             <img src="images/evo.png" style="height:65px; width:225px;" alt="" title="" class="right" />
              Компания была основана в 2016 при поддержки футбольного клуба «Evolution». Цель компании является расширенность по всему миру, и сделать себе настоящее имя.
             </p>
             
             </div>
         
             
            <div class="right_box">
             
              <div class="title"><span class="title_icon"><img src="images/bullet5.gif" alt="" title="" /></span>Категории</div> 
                
                <ul class="list">
                <?php 
                  $result = mysqli_query($con,"SELECT DISTINCT category FROM book");
                  while($row = mysqli_fetch_array($result))
                  {
                    echo "<li><a href='search.php?category=".$row['category']."'>".$row['category']."</a></li>";
                  }
                ?>                
                </ul>
             
             </div>
     
        
        </div><!--end of right content-->
        
        
       
       
       <div class="clear"></div>
       </div><!--end of center content-->
       
              
       
    

</div>

</body>
</html>