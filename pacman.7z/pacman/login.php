<?php
	session_start();
	 //SQL CONNECTION                    
    $con=mysqli_connect("localhost","root","","bookstore");
    // Check connection
    if (mysqli_connect_errno()){
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
      }
    $sql = "SELECT * FROM user WHERE name='".(strtolower($_POST['name']))."'";
    if (!mysqli_query($con,$sql)){
        die('Error: ' . mysqli_error($con));
    }    
    echo $sql;
	$bool = false;
	$result = mysqli_query($con,$sql);
  	while($row = mysqli_fetch_array($result))
	{				
		if (md5($_POST["password"]) == $row["password"]) {	 			
			$_SESSION["Login"] = $row["id"];
			if ($row["name"]=="admin")
				$_SESSION["Login"] = "admin";
		  	$bool = true;
	  	}
	}	
	if (!$bool) {		  	
	  	$_SESSION["Login"] = "NO";		 
	}		
	mysqli_close($con);
	header("Location:index.php")            
?>