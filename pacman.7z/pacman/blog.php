<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
  session_start();
  function truncate($text, $chars) {    
    if (strlen($text) <= $chars) return $text;
    $text = $text." ";
    $text = substr($text,0,$chars);
    $text = substr($text,0,strrpos($text,' '));
    $text = $text."...";
    return $text;    
 } 
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!DOCTYPE html>
<html lang="en">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>BLOG EVOLUTION</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    
    
    
  <link href="css/main.css" rel="stylesheet">
  <link href="css/responsive.css" rel="stylesheet">    

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" type="text/css" href="css/style.css" />
<script src="js/modernizr.custom.js"></script>

</head>
<body>
<div id="wrap">

       <div class="header">
          <div class="logo"><a href="index.php"><img src="images/home/evo.png" alt="" title="" border="0" style="height:40px" /></a></div>  

        <div id="menu">
            <ul>                                                                              
            <li ><a href="index.php">Главная</a></li>                        
            <span class="divider"></span>
            <li><a href="category.php">Магазин</a></li>
            <span class="divider"></span>
            <li class="selected"><a href="blog.php">Отзывы</a></li>
            <span class="divider"></span>
            <li><a href="about.php">О нас</a></li>
            <span class="divider"></span>
            <li><a href="contact.php">Контакты</a></li>
            <span class="divider"></span>
            </ul>
            <div id="div_search">
          <form method="get">
            <input name="search" type="text" size="20" style="margin-left:700px; margin-top:-80px;" placeholder="Поиск..." />
          </form></div>
        </div>
            <div id="regbar" style="margin-left: 450px; margin-top:-15px;">
          <ul>
          <?php          
          if ($_SESSION["Login"] != "NO" AND $_SESSION["Login"] != "admin") {
            echo "<li><a href='mysettings.php'>Профиль</a></li>";
            echo "<li><a href='logout.php'>Выход</a></li>";
          } else if ($_SESSION["Login"] == "admin") {
            echo "<li><a href='admin.php'>Профиль</a></li>";
            echo "<li><a href='logout.php'>Выход</a></li>";
          } else {
            echo "<li><a href='myaccount.php'>Вход</a></li>";
            echo "<li><a href='register.php'>Регистрация</a></li>";
          }
          ?>  
          </ul>            
        </div>
        </div> 

        <div class="col-sm-9">
          <div class="blog-post-area">
            <h2 class="title text-center">Последние отзывы наших клиентов</h2>
            <div class="single-blog-post">
              <h3>Билл Гейтс</h3>
              
              <a href="">
                <img src="images/blog/bill.jpg" alt="">
              </a>
              <p>Я очень доволен доставкой, поверьте говорю вам по моему опыту компания EVOLUTION может доставить товар в любую точку мира.</p>
            </div>
            <div class="single-blog-post">
              <h3>Криштиану Роналдо</h3>
              <div class="post-meta">
              </div>
              <a href="">
                <img src="images/blog/ronaldo.jpg" alt="">
              </a>
              <p>Просто не описаемо, очень восхищен качеством товара. От лица лучшего игрока мира советую всем футболистам планеты, приобретать спортивные атрибуты от компании EVOLUTION. Спасибо Вам EVOLUTION, Вы лучшие в своей сфере.</p>
            </div>
            <div class="single-blog-post">
              <h3>Нурсултан Назарбаев</h3>
            
              <a href="">
                <img src="images/blog/nazarbaev.jpg" alt="">
              </a>
              <p>И да гражданины нашей Родины, мы сумели этого достичь: выбраться не из легкой положении-Девальвация. Никому не секрет, что наша валюта была в состоянии "Плавающего курса тенге", но с компанией EVOLUTION мы нашли яркий путь в конце туннеля и сейчас мы находимся в топовых стран. Я Ваш большой поклонник.</p>
            </div>
          </div>
        </div>
        
        </div><!--end of right content-->
        
        
       
       
       <div class="clear"></div>
       </div><!--end of center content-->
       
               
       <div class="footer">
        ©Copyright Все права защищены <a href = "index.php">Kairat Toleubaev</a>
       </div>
    


</div>

</body>
</html>