<?php
//SQL CONNECTION          
session_start();          
$con=mysqli_connect("localhost","root","","bookstore");
// Check connection
if (mysqli_connect_errno()){
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
mysql_set_charset('utf8');
$sql = "SELECT cart,total FROM user WHERE id=".$_SESSION['Login'];
$cart = "";
$total = 0;
$result = mysqli_query($con,$sql);
while($row = mysqli_fetch_array($result)){
  $cart = $row['cart'];
  $total = $row['total'];
}
$sql = "SELECT price FROM book WHERE id=".$_POST['id'];
$result = mysqli_query($con,$sql);
while($row = mysqli_fetch_array($result)){  
  $total = $total + $row['price'];
}

$cart = $cart . '&' . $_POST['id'];                  
$sql = "UPDATE user SET cart='".$cart."',total=".$total." WHERE id=".$_SESSION['Login'];
if (!mysqli_query($con,$sql)){
    die('Error: ' . mysqli_error($con));
}
mysqli_close($con);            
header("Location:".$_POST['site'])
?>