<?php
	session_start();
	$con=mysqli_connect("localhost","root","","bookstore");
	// Check connection
	if (mysqli_connect_errno()){
  		echo "Failed to connect to MySQL: " . mysqli_connect_error();
  	}

  	$result = mysqli_query($con,"SELECT cart,total FROM user WHERE id=".$_SESSION['Login']);
	$cart = "";
	$total = 0;
	$count = 0;
	while($row = mysqli_fetch_array($result))
	{
		$cart = $row['cart'];
	    $total = $row['total'];                     
	}
	$array = split("&",$cart);
	$ans = "";
	$search = $_POST['idd'];
	for ($i=1; $i < sizeof($array); $i++) { 
		if ($array[$i] == $search) {
			$search = -100;
			$result = mysqli_query($con,"SELECT price FROM book WHERE id=".$array[$i]);
          	while($row = mysqli_fetch_array($result))
            {
            	$total = $total - $row['price'];
            } 
		} else {
			$ans = $ans."&".$array[$i];
		}
	}
	echo $ans . " " . $total;
	$sql = "UPDATE user SET cart='".$ans."',total='".$total."' WHERE id=".$_SESSION['Login']; 
    if (!mysqli_query($con,$sql)){
        die('Error: ' . mysqli_error($con));
    }
	mysqli_close($con);
	header("Location:cart.php");
?>
        
