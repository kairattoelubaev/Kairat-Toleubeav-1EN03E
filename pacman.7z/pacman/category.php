<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
  session_start();
      function truncate($text, $chars) {    
    if (strlen($text) <= $chars) return $text;
    $text = $text." ";
    $text = substr($text,0,$chars);
    $text = substr($text,0,strrpos($text,' '));
    $text = $text."...";
    return $text;
 }

?>

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PRODUCTS | EVOLUTION</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />

</head>
<body>
<div id="wrap">

       <div class="header">
          <div class="logo"><a href="index.php"><img src="images/home/evo.png" alt="" title="" border="0" style="height:40px" /></a></div>  

        <div id="menu">
            <ul>                                                                              
            <li><a href="index.php">Главная</a></li>                        
            <span class="divider"></span>
            <li class="selected"><a href="category.php">Магазин</a></li>
            <span class="divider"></span>
            <li><a href="blog.php">Отзывы</a></li>
            <span class="divider"></span>
            <li><a href="about.php">О нас</a></li>
            <span class="divider"></span>
            <li><a href="contact.php">Контакты</a></li>
            <span class="divider"></span>
            </ul>
            <div id="div_search">
          <form method="get">
            <input name="search" type="text" size="20" style="margin-left:700px; margin-top:-80px;" placeholder="Поиск..." />
          </form></div>
        </div>
            <div id="regbar" style="margin-left: 450px; margin-top:-15px;">
          <ul>
          <?php          
          if ($_SESSION["Login"] != "NO" AND $_SESSION["Login"] != "admin") {
            echo "<li><a href='mysettings.php'>Профиль</a></li>";
            echo "<li><a href='logout.php'>Выход</a></li>";
          } else if ($_SESSION["Login"] == "admin") {
            echo "<li><a href='admin.php'>Профиль</a></li>";
            echo "<li><a href='logout.php'>Выход</a></li>";
          } else {
            echo "<li><a href='myaccount.php'>Вход</a></li>";
            echo "<li><a href='register.php'>Регистрация</a></li>";
          }
          ?>  
          </ul>            
        </div>
        </div> 
       
       
       <div class="center_content">
       	<div class="left_content">
        	<div class="title"><span class="title_icon"><img src="images/bullet1.png" alt="" title="" /></span>Товары</div>
           
           <div class="new_products">           
            <?php                  
                  $con=mysqli_connect("localhost","root","","bookstore");
                  // Check connection
                  if (mysqli_connect_errno())
                    {
                      echo "Failed to connect to MySQL: " . mysqli_connect_error();
                    }
                  mysql_set_charset('utf8');
                  $count = 0;
                  $break = 0;
                  $paginator = 0;
                  if (!empty($_GET['pos'])) {
                        $paginator = $_GET['pos'] * 12;
                  } 
                  $result = mysqli_query($con,"SELECT * FROM book");
                  while($row = mysqli_fetch_array($result))
                  { 
     
                    if ($count >= $paginator && $break < 12){
                      echo "<div class='new_prod_box'>";                      
                      echo "<a href='details.php?id=".$row['id']."'>".truncate($row['name'] , 35)."</a>";                      
                      echo "<div class='new_prod_bg'>";
                      if ($row['status'] == "special")  echo "<span class='special_icon'><img src='images/special_icon.gif'></span>";
                      if ($row['status'] == "promo")  echo "<span class='new_icon'><img src='images/promo_icon.gif'></span>";
                      if ($row['status'] == "new")  echo "<span class='new_icon'><img src='images/new_icon.gif'></span>";                                                                
                      echo "<a href='details.php?id=".$row['id']."'><img src='images/".$row['pic']."'class='thumb' border='0' style='height:100px; width:60px;' /></a>";
                      echo "</div>";
                      echo "</div>";
                        $break++;
                    }                        
                    $count++;
                  }
                    $paginator = $paginator / 12;                    
                    echo "<div class='pagination'>";
                    if ($paginator == 0) echo "<span class='disabled'><<</span>"; else echo "<a href='?pos=0'><<</a>";
                    if ($count > 12)
                    for ($i = 0; $i < ceil($count / 12); $i++) {
                      if ($i == $paginator) echo "<span class='current'>".($i + 1)."</span>";
                      else {
                        echo "<a href='?pos=".$i."'>".($i + 1)."</a>";
                      }
                    } else { echo "<span class='current'>1</span><span class='disabled'>>></span>"; }

                    if ($paginator + 1 != ceil($count / 12)) echo "<a href='?pos=".(ceil($count / 12) - 1)."'>>></a>"; else "<span class='disabled'>>></span>";
                   //echo "<a href='?pos=2'>2</a><a href='?pos=3'>3</a>…<a href='?pos=199'>10</a><a href='?pos=200'>11</a><a href='?pos=2'>>></a>";
                    echo "</div>";
                    mysql_close();
            ?>            
          </div> 
          
            
        <div class="clear"></div>

        </div><!--end of left content-->
        
        <div class="right_content">
        	               
        <?php       
          if ($_SESSION["Login"] != "NO" AND $_SESSION["Login"] != "admin") {
              $result = mysqli_query($con,"SELECT cart,total FROM user WHERE id=" .$_SESSION['Login']);
              $cart = "";
              $total = 0;
              $length = 0;
              while($row = mysqli_fetch_array($result))
              {
                $cart = $row['cart'];
                $total = $row['total'];
              }
              $cartar = split("&",$cart);              
              if (sizeof($cartar) <= 1) $length = 0; else $length = sizeof($cartar) - 1;
              echo "<div class='cart'>";
              echo "<div class='title'><span class='title_icon'><img src='images/cart.gif' /></span>Корзина</div>";
              echo "<div class='home_cart_content'>";
              echo $length." x товар | <span class='red'>Все: ".$total."$</span>";
              echo "</div>";
              echo "<a href='cart.php' class='view_cart'>Посмотреть корзину</a>";
              echo "</div>";
          }             
        ?>            
        
        
<div class="feat_prod_box_details">
            <p class="details">
            <img src="images/football.png" style="height:150px; width:165px;" alt="" title="" class="right" /> 
             Компания «Evolution» несмотря на свои кратко месячные сроки, смогла твердо утвердить свою главную роль в маркетинговой деятельности. Более того, «Evolution» квалифицировалась в стан ведущих маркетинговых держав, что доказывает о своем авторитетном весе. Учитывая свои успехи, компания может похвастаться своими сотрудниками. Такие как: «Adidas», «Nike», «Puma», «Umbro». Исходя из всего вышесказанного, от лица компании могу сказать, купив товар, не пожалеете. 

<br />

            </p>
            
            
            </div>
                      
             <div class="right_box">
             
              <div class="title"><span class="title_icon"><img src="images/bullet5.gif" alt="" title="" /></span>Категории</div> 
                
                <ul class="list">
                <?php 
                  $result = mysqli_query($con,"SELECT DISTINCT category FROM book");
                  while($row = mysqli_fetch_array($result))
                  {
                    echo "<li><a href='search.php?category=".$row['category']."'>".$row['category']."</a></li>";
                  }
                ?>                
                </ul>
             
             </div>
     
        
        </div><!--end of right content-->
        
        
       
       
       <div class="clear"></div>
       </div><!--end of center content-->
       
              
       <div class="footer">
        
                 
       <div class="footer">
        ©Copyright Все права защищены <a href = "index.php">Kairat Toleubaev</a>
       </div>
    


</div>

</body>
</html>