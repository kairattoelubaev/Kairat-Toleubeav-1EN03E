<?php
session_start();
$_SESSION['Login'] = "NO";
header("Location:index.php")            
?>