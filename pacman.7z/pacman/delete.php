<?php
	$con=mysqli_connect("localhost","root","","bookstore");
	// Check connection
	if (mysqli_connect_errno()){
  		echo "Failed to connect to MySQL: " . mysqli_connect_error();
  	}

  	$sql = "DELETE FROM book WHERE id=".$_POST['idd'];  	
  	if (!mysqli_query($con,$sql)){
    	die('Error: ' . mysqli_error($con));
	}
	unlink("uploads/".$_POST['img']);
	mysqli_close($con);
	header("Location:admin.php?pos=".($_POST['pos'] - 1));
?>
        
