<?php
  $con=mysqli_connect("localhost","root","","bookstore");
  // Check connection
  if (mysqli_connect_errno()){
      echo "Failed to connect to MySQL: " . mysqli_connect_error();
    }
  $sql = "INSERT INTO user(name,password,email,phone,address) VALUE('".strtolower($_POST['name'])."','".md5($_POST['password'])."','".$_POST['email']."','".$_POST['phone']."','".$_POST['address']."')";
  if (!mysqli_query($con,$sql)){
      die('Error: ' . mysqli_error($con));
    }
  mysqli_close($con);
  header("Location:myaccount.php")
?>