<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php 
session_start();
$con=mysqli_connect("localhost","root","","bookstore");
// Check connection
if (mysqli_connect_errno())
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
mysql_set_charset('utf8');
$result = mysqli_query($con,"SELECT * FROM user WHERE id=".$_SESSION['Login']);
$name = "";
$email = "";
$phone = "";
$address = "";
while($row = mysqli_fetch_array($result))
{ 
  $name = $row['name'];
  $email = $row['email'];
  $phone = $row['phone'];
  $address = $row['address'];
}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PROFILE | EVOLUTION</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<script type="text/javascript" src="js/jquery-2.0.3.js"></script>
<script>
$(document).ready(function() { 
   $("#edit").click(function() {         
         $("#editoverlay").hide();
         $("#full").css("opacity","0");                                
         $("body:not(#editoverlay)").fadeTo('fast',2.0);
         $("#success2").show().fadeTo(1000,1.0).hide("medium");         
         $('#editform').delay(1000).trigger('submit');
      });
   $("#close2").click(function() {      
         $("#editoverlay").hide();
         $("body:not(#editoverlay)").fadeTo('fast',2.0);
         $("#full").hide();
      });
});
function edit(){      
      name=<?php echo "'".$name."'";?>;
      email=<?php echo "'".$email."'";?>;
      phone=<?php echo "'".$phone."'";?>;
      address=<?php echo "'".$address."'";?>;
      s = "";
      $("#editform").empty();      
      $("#editform").append("<div class='form_row'><label class='contact'><strong>Есім:</strong></label><input type='text' class='contact_input' name='name' value='"+name+"' readonly/></div>");
      $("#editform").append("<div class='form_row'><label class='contact'><strong>Құпиясөз:</strong></label><input type='password' class='contact_input' name='password' placeholder='********'/></div>");      
      $("#editform").append("<div class='form_row'><label class='contact'><strong>Е-пошта:</strong></label><input type='text' class='contact_input' name='email' value='"+email+"'/></div>");
      $("#editform").append("<div class='form_row'><label class='contact'><strong>Телефон:</strong></label><input type='text' class='contact_input' name='phone'  value='"+phone+"'/></div>");
      $("#editform").append("<div class='form_row'><label class='contact'><strong>Мекенжай:</strong></label><input type='text' class='contact_input' name='address'  value='"+address+"'/></div>");
      $("#editform").append("<input type='text' style='display:none;' name='ide'  value='"+<?php echo $_SESSION['Login']?>+"'/>");
      $("#editoverlay").show();
      $("#full").show();
   }
</script>

</head>
<body>
<div id="wrap">

       <div class="header">
          <div class="logo"><a href="index.php"><img src="images/home/evo.png" alt="" title="" border="0" style="height:40px" /></a></div>  

        <div id="menu">
            <ul>                                                                              
            <li class="selected"><a href="index.php">Главная</a></li>                        
            <span class="divider"></span>
            <li><a href="category.php">Магазин</a></li>
            <span class="divider"></span>
            <li><a href="blog.php">Отзывы</a></li>
            <span class="divider"></span>
            <li><a href="about.php">О нас</a></li>
            <span class="divider"></span>
            <li><a href="contact.php">Контакты</a></li>
            <span class="divider"></span>
            </ul>
            <div id="div_search">
          <form method="get">
            <input name="search" type="text" size="20" style="margin-left:700px; margin-top:-80px;" placeholder="Поиск..." />
          </form></div>
        </div>
            <div id="regbar" style="margin-left: 450px; margin-top:-15px;">
          <ul>
          <?php          
          if ($_SESSION["Login"] != "NO" AND $_SESSION["Login"] != "admin") {
            echo "<li><a href='mysettings.php'>Профиль</a></li>";
            echo "<li><a href='logout.php'>Выход</a></li>";
          } else if ($_SESSION["Login"] == "admin") {
            echo "<li><a href='admin.php'>Профиль</a></li>";
            echo "<li><a href='logout.php'>Выход</a></li>";
          } else {
            echo "<li><a href='myaccount.php'>Вход</a></li>";
            echo "<li><a href='register.php'>Регистрация</a></li>";
          }
          ?>  
          </ul>            
        </div>
        </div> 
       
       
       <div class="center_content">
       	<div class="left_content">
            <div class="title"><span class="title_icon"><img src="images/bullet1.png" alt="" title="" /></span>Мой профиль</div>
        
        	<div class="feat_prod_box_details">            
            
              	<div class="contact_form">
                 <form name="register" action="registerme.php" method="post" id="myform">          
                    <div class="form_row">
                    <label class="contact"><strong>Имя:</strong></label>
                    <input type='text' class='contact_input' name='name' value=<?php echo "'".$name."'";?> readonly/>
                    </div>  
                    
                    <div class="form_row">
                    <label class="contact"><strong>Э-почта:</strong></label>
                    <input type="text" class="contact_input" name="email" value=<?php echo "'".$email."'";?> readonly/>
                    </div>

                    <div class="form_row">
                    <label class="contact"><strong>Телефон:</strong></label>
                    <input type="text" class="contact_input" name="phone" value=<?php echo "'".$phone."'";?> readonly/>
                    </div>
                                        
                    <div class="form_row">
                    <label class="contact"><strong>Адресс:</strong></label>
                    <input type="text" class="contact_input" name="address" value=<?php echo "'".$address."'";?> readonly/>
                    </div>                    
                    
                    <a href="#" id="update" class="button button-brown" style="margin-left:205px" onclick="edit()">
                        <span>Изменить</span>
                    </a>
                    <input type="submit" class="register" value="register" style="display:none"  />
                    
                  </form>     
                </div>  
            
          </div>	
            
              

            

            
        <div class="clear"></div>
        </div><!--end of left content-->
        
        <div class="right_content">
            <?php       
          if ($_SESSION["Login"] != "NO" AND $_SESSION["Login"] != "admin") {
              $result = mysqli_query($con,"SELECT cart,total FROM user WHERE id=" .$_SESSION['Login']);
              $cart = "";
              $total = 0;
              $length = 0;
              while($row = mysqli_fetch_array($result))
              {
                $cart = $row['cart'];
                $total = $row['total'];
              }
              $cartar = split("&",$cart);              
              if (sizeof($cartar) <= 1) $length = 0; else $length = sizeof($cartar) - 1;
              echo "<div class='cart'>";
              echo "<div class='title'><span class='title_icon'><img src='images/cart.gif' /></span>Корзина</div>";
              echo "<div class='home_cart_content'>";
              echo $length." Товаров | <span class='red'>Всего: ".$total."$</span>";
              echo "</div>";
              echo "<a href='cart.php' class='view_cart'>Корзина</a>";
              echo "</div>";
          }             
        ?>            
        
        
             <div class="title"><span class="title_icon"><img src="images/bullet3.gif" alt="" title="" /></span>О компании</div> 
             <div class="about">
             <p>
             <img src="images/evo.png" style="height:65px; width:225px;" alt="" title="" class="right" />
              Компания была основана в 2016 при поддержки футбольного клуба «Evolution». Цель компании является расширенность по всему миру, и сделать себе настоящее имя.
              
             </p>
             
             </div>
         
             
             <div class="right_box">
             
             	<div class="title"><span class="title_icon"><img src="images/bullet5.gif" alt="" title="" /></span>Категории</div> 
                
                <ul class="list">
                <?php 
                  $result = mysqli_query($con,"SELECT DISTINCT category FROM book");
                  while($row = mysqli_fetch_array($result))
                  {
                    echo "<li><a href='search.php?category=".$row['category']."'>".$row['category']."</a></li>";
                  }
                ?>                
                </ul>
             
             </div>
             
          <div id="editoverlay">
            <form action="edituser.php" method="post" enctype="multipart/form-data" id="editform">
              <input type="submit" action="edituser.php" value="Edit" style="display:none">            
            </form>
            <a href="#" id="close2" class="button button-brown" style="margin-left:15px">
              <span>Закрыть</span>
            </a>
           <a href="#" id="edit" class="button button-brown" style="margin-left:15px">
              <span>Изменить</span>
            </a>    
          </div>
          <div id="full"> </div>
        </div><!--end of right content-->
        
        
       
       
       
       <div class="clear"></div>
       </div><!--end of center content-->
       
              
       <div class="footer">
        
        <div class="footer">
        ©Copyright Все права защищены <a href = "index.php">Kairat Toleubaev</a>
       </div>
    
    

</div>

</body>
</html>