<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
  session_start();
  function truncate($text, $chars) {    
    if (strlen($text) <= $chars) return $text;
    $text = $text." ";
    $text = substr($text,0,$chars);
    $text = substr($text,0,strrpos($text,' '));
    $text = $text."...";
    return $text;    
 } 
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!DOCTYPE html>
<html lang="en">

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | EVOLUTION</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    
    
    
  <link href="css/main.css" rel="stylesheet">
  <link href="css/responsive.css" rel="stylesheet">    

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

<link rel="stylesheet" type="text/css" href="css/style.css" />
<script src="js/modernizr.custom.js"></script>

</head>
<body>
<div id="wrap">

       <div class="header">
          <div class="logo"><a href="index.php"><img src="images/home/evo.png" style="height:50px;  float:left;  " alt="" title="" border="0" style="height:40px" /></a></div>  

        <div id="menu">
            <ul>                                                                              
            <li class="selected"><a href="index.php">Главная</a></li>                        
            <span class="divider"></span>
            <li><a href="category.php">Магазин</a></li>
            <span class="divider"></span>
            <li><a href="blog.php">Отзывы</a></li>
            <span class="divider"></span>
            <li><a href="about.php">О нас</a></li>
            <span class="divider"></span>
            <li><a href="contact.php">Контакты</a></li>
            <span class="divider"></span>
            </ul>
            <div id="div_search">
          <form method="get">
            <input name="search" type="text" size="20" style="margin-left:700px; margin-top:-80px;" placeholder="Поиск..." />
          </form></div>
        </div>
            <div id="regbar" style="margin-left: 450px; margin-top:-15px;">
          <ul>
          <?php
          if (isset($_SESSION["Login"])) {     
            if ($_SESSION["Login"] != "NO" AND $_SESSION["Login"] != "admin") {
              echo "<li><a href='mysettings.php'>Профиль</a></li>";
              echo "<li><a href='logout.php'>Выход</a></li>";
            } else if ($_SESSION["Login"] == "admin") {
              echo "<li><a href='admin.php'>Профиль</a></li>";
              echo "<li><a href='logout.php'>Выход</a></li>";
            } else {
              echo "<li><a href='myaccount.php'>Вход</a></li>";
              echo "<li><a href='register.php'>Регистрация</a></li>";
            }
            
          }     
          ?>  
          </ul>            
        </div>
        </div> 

        <div class="carousel-inner">
              <div class="item active">
                <div class="col-sm-6">
                  <h1>EVOLUTION</h1>
                  <h2>Не упусти свой шанс получить автограф</h2>
                  <p>При покупки 3-х товаров у тебя есть шанс получить автограф игрока Evolution - Толеубаева Кайрата </p>
                  <a href="category.php"><button type="button" class="btn btn-default get">Купить сейчас</button></a>
                </div>
                <div class="col-sm-6">
                  <img src="images/fotka1.png" class="girl img-responsive" alt="" />
                </div>
              </div>
              <div class="item">
                <div class="col-sm-6">
                  <h1><span>E</span>-SHOPPER</h1>
                  <h2>100% Responsive Design</h2>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                  <button type="button" class="btn btn-default get">Get it now</button>
                </div>
                <div class="col-sm-6">
                  <img src="images/home/girl2.jpg" class="girl img-responsive" alt="" />
                  <img src="images/home/pricing.png"  class="pricing" alt="" />
                </div>
              </div>
              
              <div class="item">
                <div class="col-sm-6">
                  <h1><span>E</span>-SHOPPER</h1>
                  <h2>Free Ecommerce Template</h2>
                  <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. </p>
                  <button type="button" class="btn btn-default get">Get it now</button>
                </div>
                <div class="col-sm-6">
                  <img src="images/home/girl3.jpg" class="girl img-responsive" alt="" />
                  <img src="images/home/pricing.png" class="pricing" alt="" />
                </div>
            </div>
        
               
       </div> 
              
       
       <div class="center_content">
       	<div class="left_content">
        	
            <div class="title"><span class="title_icon"><img src="images/bullet1.png" alt="" title="" /></span>Популяррные</div>
          <?php
                  $con=mysqli_connect("localhost","root","","bookstore");
                  // Check connection
                  if (mysqli_connect_errno())
                    {
                      echo "Failed to connect to MySQL: " . mysqli_connect_error();
                    }                                    
                  $result = mysqli_query($con,"SELECT * FROM (SELECT * FROM book ORDER BY id DESC LIMIT 2) sub ORDER BY id ASC");
                  while($row = mysqli_fetch_array($result))
                  {                                         
                    echo "<div class='feat_prod_box'>";
                    echo "<div class='prod_img'><a href='details.php?id=".$row['id']."'><img src=images/".$row['pic']."  border='0' style='height:150px; width:100px;' /></a></div>";
                    echo "<div class='prod_det_box'>";
                    if ($row['status'] == "special") 
                      echo "<span class='special_icon'><img src='images/special_icon.gif'></span>";
                    if ($row['status'] == "promo") 
                      echo "<span class='special_icon'><img src='images/promo_icon.gif'></span>";
                    if ($row['status'] == "new") 
                      echo "<span class='special_icon'><img src='images/new_icon.gif'></span>";
                    echo "<div class='box_top'></div>";
                    echo "<div class='box_center'>";
                    echo "<div class='prod_title'>".$row['name']."</div>";
                    echo "<p class='details'>".truncate($row['details'] , 300)."</p>";
                    echo "<a href='details.php?id=".$row['id']."' class='more'></a>";
                    echo "<div class='clear'></div>";
                    echo "</div>";
                    
                    echo "<div class='box_bottom'></div>";
                    echo "</div>";
                    echo "<div class='clear'></div>";
                    echo "</div>";                    
                  }                  
          ?>            
            
            
           <?php

              echo "<div class='title'><span class='title_icon'><img src='images/bullet2.png' /></span>Новые</div>";
              echo "<div class='new_products'>"; 
                  $count = 0;
                  $result = mysqli_query($con,"SELECT * FROM book WHERE status='new' or status='promo'");
                  while($row = mysqli_fetch_array($result))
                  {                                         
                                                       
                             echo "<div class='new_prod_box'>
                             <a href='details.php?id=".$row['id']."'>".truncate($row['name'] , 35)."</a>
                             <div class='new_prod_bg'>";                             
                             if ($row['status'] == "promo")  echo "<span class='new_icon'><img src='images/promo_icon.gif'></span>";
                             if ($row['status'] == "new")  echo "<span class='new_icon'><img src='images/new_icon.gif'></span>";                                                                
                             echo "<a href='details.php?id=".$row['id']."'><img src='images/".$row['pic']."' class='thumb' border='0' style='height:100px; width:60px;' /></a>
                             </div>           
                         </div>";
               
                 
                        

                    if ($count == 3) break;
                    $count++;
                  }
                  echo "</div><div class='clear'></div>";
                  //mysql_close();
        ?>
        </div><!--end of left content-->
        
        <div class="right_content">
        	               
         <?php       
          if ($_SESSION["Login"] != "NO" AND $_SESSION["Login"] != "admin") {
              $result = mysqli_query($con,"SELECT cart,total FROM user WHERE id=" .$_SESSION['Login']);
              $cart = "";
              $total = 0;
              $length = 0;
              while($row = mysqli_fetch_array($result))
              {
                $cart = $row['cart'];
                $total = $row['total'];
              }
              $cartar = split("&",$cart);              
              if (sizeof($cartar) <= 1) $length = 0; else $length = sizeof($cartar) - 1;
              echo "<div class='cart'>";
              echo "<div class='title'><a href='cart.php' class='view_cart'> <span class='title_icon'><img src='images/cart.gif'/></span>Корзина</div> </a>";
              echo "<div class='home_cart_content'>";
              
              echo "</div>";
              echo "</div>";
          }             
        ?>          	
        
        
             <div class="title"><span class="title_icon"><img src="images/bullet3.gif" alt="" title="" /></span>О компании</div> 
             <div class="about">
             <p>
             <img src="images/evo.png" style="height:65px; width:225px;" alt="" title="" class="right" />
              Компания была основана в 2016 при поддержки футбольного клуба «Evolution». Цель компании является расширенность по всему миру, и сделать себе настоящее имя.
              
             </p>
             
             </div>
             
              <div class="right_box">
             
              <div class="title"><span class="title_icon"><img src="images/bullet5.gif" alt="" title="" /></span>Категории</div> 
                
                <ul class="list">
                <?php 
                  $result = mysqli_query($con,"SELECT DISTINCT category FROM book");
                  while($row = mysqli_fetch_array($result))
                  {
                    echo "<li><a href='search.php?category=".$row['category']."'>".$row['category']."</a></li>";
                  }
                ?>                
                </ul>
             
             </div>
     
        
        </div><!--end of right content-->       
       <div class="clear"></div>
       </div><!--end of center content-->
       
              
       <div class="footer">
       	©Copyright Все права защищены <a href = "index.php">Kairat Toleubaev</a>
       </div>
    

</div>

</body>
</html>