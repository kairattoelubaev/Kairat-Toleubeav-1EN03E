<?php
$con=mysqli_connect("localhost","root","","bookstore");
// Check connection
if (mysqli_connect_errno()){
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
mysql_set_charset('utf8');
$sql = "INSERT INTO contact (name,email,phone,company,message) VALUES('".$_POST['name']."','".$_POST['email']."','".$_POST['phone']."','".$_POST['company']."','".$_POST['message']."')";
if (!mysqli_query($con,$sql)){
    die('Error: ' . mysqli_error($con));
}
mysqli_close($con);            
header("Location:contact.php");
?>