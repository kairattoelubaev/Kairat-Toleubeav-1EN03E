<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
  session_start();
  if ($_SESSION['Login'] != "admin") header("Location:index.php");  
  function truncate($text, $chars) {    
    if (strlen($text) <= $chars) return $text;
    $text = $text." ";
    $text = substr($text,0,$chars);
    $text = substr($text,0,strrpos($text,' '));
    $text = $text."...";
    return $text;
 }
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Көкжиек</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<script type="text/javascript" src="js/jquery-2.0.3.js"></script>
<script>
var gid = 0;
var img = "";
   $(document).ready(function() { 
      $("#trigger").click(function() {
         $("#overlay").show();
         $("#overlay").fadeTo(1000,1.0);
         $("#full").show();        
      });

      $("#close").click(function() {
         $("#overlay").hide();
         $("body:not(#overlay)").fadeTo('fast',2.0);
         $("#full").hide();
      });

      $("#close1").click(function() {
         $("#askin").hide();
         $("body:not(#askin)").fadeTo('fast',2.0);
         $("#full").hide();
      });

      $("#close2").click(function() {      
         $("#editoverlay").hide();
         $("body:not(#editoverlay)").fadeTo('fast',2.0);
         $("#full").hide();
      });

      $("#add").click(function() {         
         $("#overlay").hide();
         $("body:not(#overlay)").fadeTo('fast',2.0);
         $("#success").show().fadeTo(1000,1.0).hide("medium");
         $("#full").delay(1000).hide("medium");         
         $("#pos").val($(".current").text());        
         $('#myform').delay(1000).trigger('submit');
      });
      $("#edit").click(function() {         
         $("#editoverlay").hide();
         $("body:not(#editoverlay)").fadeTo('fast',2.0);
         $("#success2").show().fadeTo(1000,1.0).hide("medium");
         $("#full").delay(1000).hide("medium");         
         $("#pos").val($(".current").text());        
         $("#ide").val(gid);        
         $("#img").val(img);                        
         $('#editform').delay(1000).trigger('submit');
      });
      $("#delete").click(function(){                  
         $("#askin").hide();
         $("body:not(#askin)").fadeTo('fast',2.0);
         $("#success1").show().fadeTo(1000,1.0).hide("medium");
         $("#full").delay(1000).hide("medium");
         $("#idd").val(gid);                           
         $("#img").val(img);                            
         $("#pos").val($(".current").text());        
         $('#myform1').delay(1000).trigger('submit');
      });
      $("#overlay").hide();
      $("#boxConf").hide();
    });

   function edit(id){
      gid=id;
      s = "";
      $("#editform").empty();
      $.post('retrive.php', 'id=' + id, function (response) {
        s = response;      
        array = s.split("|");       
        img=array[5];        
        $("#editform").append("<div class='form_row'><label class='regbook'><strong>Name:</strong></label><input type='text' class='regbook_input' name='name' value='"+ array[0]+"' ></div>");
        $("#editform").append("<div class='form_row'><label class='regbook'><strong>Author:</strong></label><input type='text' class='regbook_input' name='author' value='"+ array[1]+"'></div>");
        $("#editform").append("<div class='form_row'><label class='regbook'><strong>Pages:</strong></label><input type='text' class='regbook_input' name='page' value='"+ array[2]+"'></div>");
        $("#editform").append("<div class='form_row'><label class='regbook'><strong>Year:</strong></label><input type='text' class='regbook_input' name='year' value='"+ array[3]+"'></div>");
        $("#editform").append("<div class='form_row'><label class='regbook'><strong>Category:</strong></label><input type='text' class='regbook_input' name='category' value='"+ array[4]+"'></div>");
        $("#editform").append("<div class='form_row'><label class='regbook'><strong>Price:</strong></label><input type='text' class='regbook_input' name='price'  value='"+ array[7]+"'></div>");
        $("#editform").append("<label class='adminstatus'><strong>Status:</strong></label>");
        $("#editform").append("<input class='radiostatus' type='radio' name='status' value='new' "+(array[8]=='new' ? 'checked' : '')+"/>New");
        $("#editform").append("<input class='radiostatus' type='radio' name='status' value='promo' "+(array[8]=='promo' ? 'checked' : "")+"/>Promo");
        $("#editform").append("<input class='radiostatus' type='radio' name='status' value='special' "+(array[8]=='special' ? 'checked' : "")+"/>Special");
        $("#editform").append("<input class='radiostatus' type='radio' name='status' value='normal' "+(array[8]=='normal' ? 'checked' : "")+" />Normal <br />");
        $("#editform").append("<p class='formfield'><label for='textarea'><strong>Details:</strong></label><textarea id='textarea' rows='5' name='details'>"+ array[6]+"</textarea></p>");
        $("#editform").append("<label for='file' style='padding-left:20px;'><strong>Picture:</strong></label><input type='file' name='file' id='file'><br />");
        $("#editform").append("<input type='text' name='ide' id='ide' style='display:none'>");
        $("#editform").append("<input type='text' name='img' id='img' style='display:none'>");
        $("#editform").append("<input type='text' name='pos' id='pos' style='display:none'>");
        $("#editoverlay").show();
       $("#full").show();  
     });
   }

   function del(id,name,pic){
      gid = id;
      img = pic;
      if ($("#pdel").length > 0){
        $("#pdel").remove();
      }
      $("#askin").show();      
      $( "<p id='pdel'>Do you really want to delete \"" + name + "\"?<p>").insertBefore("#close1");
      $("#full").show();
   }
</script>
</head>
<body>
<div id="wrap">

       <div class="header">
            <div class="logo"><a href="index.php"><img src="images/logo.png" alt="" title="" border="0" style="height:40px" /></a></div>            
        <div id="menu">
            <ul>                                                                       
            <li><a href="index.php">Басқы бет</a></li>            
            <li><a href="category.php">Кітаптар</a></li>
            <li><a href="specials.php">Ерекше кітаптар</a></li>
            <li><a href="about.php">Біз туралы</a></li>
            <li><a href="contact.php">Хабарласу</a></li>
            </ul>
        </div>     
        <div id="regbar">
          <ul>
            <li><a href="admin.php">Профиль</a></li>
            <li><a href="logout.php">Шығу</a></li>
          </ul>  
        </div>
        <div id="div_search">
          <form method="get" action="search.php" id="search">
            <input name="search" type="text" size="40" placeholder="Іздеу..." />
          </form>
        </div>    
            
       </div> 
       
       
       <div class="center_content">
       	<div class="left_content">
        	
            <div class="title"><span class="title_icon"><img src="images/bullet1.png" alt="" title="" /></span>Books</div>
            <?php                  
                  $con=mysqli_connect("localhost","root","","bookstore");
                  // Check connection
                  if (mysqli_connect_errno())
                    {
                      echo "Failed to connect to MySQL: " . mysqli_connect_error();
                    }
                  mysql_set_charset('utf8');
                  $count = 0;
                  $break = 0;
                  $paginator = 0;
                  if (!empty($_GET['pos'])) {
                        $paginator = $_GET['pos'] * 3;
                  } 
                  $result = mysqli_query($con,"SELECT * FROM book");
                  while($row = mysqli_fetch_array($result))
                  { 
     
                    if ($count >= $paginator && $break < 3){
                      echo "<div class='feat_prod_box'>";
                      echo "<div class='prod_img'><a href='details.php?id=".$row['id']."'><img src=uploads/".$row['pic']."  border='0' style='height:150px; width:100px;' /></a></div>";
                      echo "<div class='prod_det_box'>";
                      
                        //echo "<span class='delete_icon'><img src='images/delete.png' style='height:18px'></span>";
                        echo "<input type='button' class='delete_icon' onClick=del(".$row['id'].",'".$row['name']."','".$row['pic']."')>";
                        echo "<input type='button' class='edit_icon' onClick=edit(".$row['id'].")>";                     
                        
                        echo "<div class='box_top'></div>";
                        echo "<div class='box_center'>";
                        echo "<div class='prod_title'>".$row['name']."</div>";
                        echo "<p class='details' style='padding-right:15px;'>".truncate($row['details'] , 300)."</p>";
                        echo "<a href='details.php?id=".$row['id']."' class='more'>- more details -</a>";
                        echo "<div class='clear'></div>";
                        echo "</div>";
                        
                        echo "<div class='box_bottom'></div>";
                        echo "</div>";
                        echo "<div class='clear'></div>";
                        echo "</div>";
                        $break++;
                    }                        
                    $count++;
                  }
                   $paginator = $paginator / 3;                    
                    echo "<div class='pagination'>";
                    if ($paginator == 0) echo "<span class='disabled'><<</span>"; else echo "<a href='?pos=0'><<</a>";
                    if ($count > 3){
                    for ($i = 0; $i < ceil($count / 3); $i++) {
                      if ($i == $paginator) echo "<span class='current'>".($i + 1)."</span>";
                      else {
                        echo "<a href='?pos=".$i."'>".($i + 1)."</a>";
                      }
                    } }else { echo "<span class='current'>1</span><span class='disabled'>>></span>"; } 
                    if ($paginator + 1 != ceil($count / 3) && $count > 3) echo "<a href='?pos=".(ceil($count / 3) - 1)."'>>></a>"; else "<span class='disabled'>>></span>";
                   //echo "<a href='?pos=2'>2</a><a href='?pos=3'>3</a>…<a href='?pos=199'>10</a><a href='?pos=200'>11</a><a href='?pos=2'>>></a>";
                    echo "</div>";
                    mysql_close();
            ?>
        <div class="clear"></div>
        <div id="full"> </div>
        <div id="overlay">
          <form action="add.php" method="post" enctype="multipart/form-data" id="myform">
            <div class="form_row">
                    <label class="regbook"><strong>Name:</strong></label>
                    <input type="text" class="regbook_input" name="name" >
            </div>
            <div class="form_row">
                    <label class="regbook"><strong>Author:</strong></label>
                    <input type="text" class="regbook_input" name="author">
            </div>
            <div class="form_row">
                    <label class="regbook"><strong>Pages:</strong></label>
                    <input type="text" class="regbook_input" name="page">
            </div>
            <div class="form_row">
                    <label class="regbook"><strong>Year:</strong></label>
                    <input type="text" class="regbook_input" name="year">
            </div>
            <div class="form_row">
                    <label class="regbook"><strong>Category:</strong></label>
                    <input type="text" class="regbook_input" name="category">
            </div>
            <div class="form_row">
                    <label class="regbook"><strong>Price:</strong></label>
                    <input type="text" class="regbook_input" name="price">
            </div>
            <label class="adminstatus"><strong>Status:</strong></label> 
            <input class="radiostatus" type="radio" name="status" value="new" />New
            <input class="radiostatus" type="radio" name="status" value="promo" />Promo
            <input class="radiostatus" type="radio" name="status" value="special" />Special
            <input class="radiostatus" type="radio" name="status" value="normal" />Normal
            <br />   
            <p class="formfield">              
              <label for="textarea"><strong>Details:</strong></label>
              <textarea id="textarea" rows="5" name="details"></textarea>
            </p>
            <label for="file" style="padding-left:20px;"><strong>Picture:</strong></label>
            <input type="file" name="file" id="file"><br>
            <a href="#" id="close" class="button button-brown" style="margin-left:75px">
              <span>Close</span>
            </a>
            <a href="#" id="add" class="button button-brown" style="margin-left:15px">
              <span>Add</span>
            </a>            
            <input type="submit" action="add.php" value="Add" style="display:none">
            <input type="text" name="pos" id="pos" style="display:none">
            </form>
          </div>
          
          <div id="editoverlay">
            <form action="edit.php" method="post" enctype="multipart/form-data" id="editform">
              <input type="submit" action="edit.php" value="Edit" style="display:none">            
            </form>
            <a href="#" id="close2" class="button button-brown" style="margin-left:75px">
              <span>Close</span>
            </a>
           <a href="#" id="edit" class="button button-brown" style="margin-left:15px">
              <span>Edit</span>
            </a>    
          </div>
        

          <div id="success">
            <p><img src='images/tick.png' style='height:30px'>Book has been successfully added!</p>
          </div>          
          <div id="success1">
            <p><img src='images/tick.png' style='height:30px'>Book has been successfully deleted!</p>
          </div>
          <div id="success2">
            <p><img src='images/tick.png' style='height:30px'>Book has been successfully edited!</p>
          </div>

          <form action="delete.php" method="post" id="myform1">              
            <input type="text" name="idd" id="idd" style="display:none">
            <input type="text" name="img" id="img" style="display:none">
            <input type="text" name="pos" id="pos" style="display:none">
            <input type="submit" action="delete.php" value="Add" style="display:none">              
          </form>
        <div id="askin">  
          <a href="#" id="close1" class="button button-brown" style="margin-left:75px">
            <span>Close</span>
          </a>
          <a href="#" id="delete" class="button button-brown" style="margin-left:15px">
            <span>Delete</span>
          </a>                                   
        </div>

        <a href="#" class="button button-brown" id="trigger">
          <span>Add</span>
        </a>

        <div class="clear"></div>
        </div><!--end of left content-->
        
        <div class="right_content">        	               
             <div class="title"><span class="title_icon"><img src="images/bullet3.gif" alt="" title="" /></span>About Our Store</div> 
             <div class="about">
             <p>
             <img src="images/about.gif" alt="" title="" class="right" />
             Баспа ұжымы қысқа уақыт аралығында діни-танымдық және рухани-мәдени тақырыптағы мазмұнды еңбектерімен республикаға танылып, осы саладағы еліміздің жетекші баспаларының бірі болып үлгерді.
             </p>
             
             </div>
             
             <div class="right_box">
             
             	<div class="title"><span class="title_icon"><img src="images/bullet5.gif" alt="" title="" /></span>Categories</div> 
                
                <ul class="list">
                <?php 
                  $result = mysqli_query($con,"SELECT DISTINCT category FROM book");
                  while($row = mysqli_fetch_array($result))
                  {
                    echo "<li><a href='search.php?category=".$row['category']."'>".$row['category']."</a></li>";
                  }
                ?>                
                </ul>           
             
             </div>
    </div>         
    <!--end of right content-->
        
        
       
       
       <div class="clear"></div>
       </div><!--end of center content-->
       
              
       <div class="footer">
       	  <div class="right_footer">
             <strong>Address: </strong> Мақатаев көшесі, 128А үй, Алматы қаласы,050004<br /> 
<strong>Email:</strong> 19danielh93@gmail.com<br  />
<strong>Phone:</strong> +7 727 279 93 14
		      </div>
       </div>
    

</div>
</body>
</html>