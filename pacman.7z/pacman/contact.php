<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<?php
  session_start();
$con=mysqli_connect("localhost","root","","bookstore");
// Check connection
if (mysqli_connect_errno())
{
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}
mysql_set_charset('utf8');
$name = "";
$email = "";
$phone = "";
$address = "";
if ($_SESSION["Login"] != "NO") {
  $result = mysqli_query($con,"SELECT * FROM user WHERE id=".$_SESSION['Login']);
  while($row = mysqli_fetch_array($result))
    { 
      $name = $row['name'];
      $email = $row['email'];
      $phone = $row['phone'];
      $address = $row['address'];
    }
}
?>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>CONTACTS | EVOLUTION</title>
<link rel="stylesheet" type="text/css" href="css/style.css" />
<script type="text/javascript" src="js/jquery-2.0.3.js"></script>
<script>
$(document).ready(function() { 
  $("#send").click(function(){                              
         $("#success").show().fadeTo(1000,1.0).hide("medium");
         $("#full").css("opacity","0");              
         $('#myform').delay(2000).trigger('submit');
      });
});
</script>
</head>
<body>
<div id="wrap">

       <div class="header">
          <div class="logo"><a href="index.php"><img src="images/home/evo.png" alt="" title="" border="0" style="height:40px" /></a></div>  

        <div id="menu">
            <ul>                                                                              
            <li ><a href="index.php">Главная</a></li>                        
            <span class="divider"></span>
            <li><a href="category.php">Магазин</a></li>
            <span class="divider"></span>
            <li><a href="blog.php">Отзывы</a></li>
            <span class="divider"></span>
            <li><a href="about.php">О нас</a></li>
            <span class="divider"></span>
            <li class="selected"><a href="contact.php">Контакты</a></li>
            <span class="divider"></span>
            </ul>
            <div id="div_search">
          <form method="get">
            <input name="search" type="text" size="20" style="margin-left:700px; margin-top:-80px;" placeholder="Поиск..." />
          </form></div>
        </div>
            <div id="regbar" style="margin-left: 450px; margin-top:-15px;">
          <ul>
          <?php          
          if ($_SESSION["Login"] != "NO" AND $_SESSION["Login"] != "admin") {
            echo "<li><a href='mysettings.php'>Профиль</a></li>";
            echo "<li><a href='logout.php'>Выход</a></li>";
          } else if ($_SESSION["Login"] == "admin") {
            echo "<li><a href='admin.php'>Профиль</a></li>";
            echo "<li><a href='logout.php'>Выход</a></li>";
          } else {
            echo "<li><a href='myaccount.php'>Вход</a></li>";
            echo "<li><a href='register.php'>Регистрация</a></li>";
          }
          ?>  
          </ul>            
        </div>
        </div> 
       
       <div class="center_content">
       	<div class="left_content">
            <div class="title"><span class="title_icon"><img src="images/bullet1.png" alt="" title="" /></span>Отправить сообщение</div>
        
        	<div class="feat_prod_box_details">
            <p class="details">
              
            </p>
            
              	<div class="contact_form">
                <div class="form_subtitle">Сообщение</div> 
                <form method="post" action="contacthandle.php" id="myform">         
                    <div class="form_row">
                    <label class="contact"><strong>Имя:</strong></label>
                    <input type="text" class="contact_input" name="name" value= <?php echo "\"".$name."\"";?> />
                    </div>  

                    <div class="form_row">
                    <label class="contact"><strong>Э-почта:</strong></label>
                    <input type="text" class="contact_input" name="email" value= <?php echo "\"".$email."\"";?> />
                    </div>


                    <div class="form_row">
                    <label class="contact"><strong>Телефон:</strong></label>
                    <input type="text" class="contact_input" name="phone" value= <?php echo "\"".$phone."\"";?>/>
                    </div>
                    
                    <div class="form_row" style="height:150px;">
                    <label class="contact"><strong>Сообщение:</strong></label>
                    <textarea class="contact_textarea" name="message" ></textarea>
                    </div>

                      <a href="#" id="send" class="button button-brown" style="margin-left:195px">
                        <span>Отправка</span>
                      </a>            
                      <input type="submit" action="contacthandle.php" value="contact" style="display:none">
                 </form>         
                </div>  
            
          </div>	
          <div id="full"> </div>  
          <div id="success">
            <p><img src='images/tick.png' style='height:30px'>Сообщение отправлено!</p>
          </div> 

            

            
        <div class="clear"></div>
        </div><!--end of left content-->
        
        <div class="right_content">
       
        <?php       
          if ($_SESSION["Login"] != "NO" AND $_SESSION["Login"] != "admin") {
              $result = mysqli_query($con,"SELECT cart,total FROM user WHERE id=" .$_SESSION['Login']);
              $cart = "";
              $total = 0;
              $length = 0;
              while($row = mysqli_fetch_array($result))
              {
                $cart = $row['cart'];
                $total = $row['total'];
              }
              $cartar = split("&",$cart);              
              if (sizeof($cartar) <= 1) $length = 0; else $length = sizeof($cartar) - 1;
              echo "<div class='cart'>";
              echo "<div class='title'><span class='title_icon'><img src='images/cart.gif' /></span>Корзина</div>";
              echo "<div class='home_cart_content'>";
              echo $length." x товар | <span class='red'>Все: ".$total."$</span>";
              echo "</div>";
              echo "<a href='cart.php' class='view_cart'>посмотреть корзину</a>";
              echo "</div>";
          }             
        ?>            
        
        
             <div class="title"><span class="title_icon"><img src="images/bullet3.gif" alt="" title="" /></span>О компании</div> 
             <div class="about">
             <p>
             <img src="images/evo.png" style="height:65px; width:225px;" alt="" title="" class="right" />
              Компания была основана в 2016 при поддержки футбольного клуба «Evolution». Цель компании является расширенность по всему миру, и сделать себе настоящее имя.
              
             </p>
             
             </div>
         
             
            <div class="right_box">
             
              <div class="title"><span class="title_icon"><img src="images/bullet5.gif" alt="" title="" /></span>Категории</div> 
                
                <ul class="list">
                <?php 
                  $result = mysqli_query($con,"SELECT DISTINCT category FROM book");
                  while($row = mysqli_fetch_array($result))
                  {
                    echo "<li><a href='search.php?category=".$row['category']."'>".$row['category']."</a></li>";
                  }
                ?>                
                </ul>
             
             </div>
     
        
        </div><!--end of right content-->
        
        
       
       
       <div class="clear"></div>
       </div><!--end of center content-->
       
              
       <div class="footer">
        
                   
       <div class="footer">
        ©Copyright Все права защищены <a href = "index.php">Kairat Toleubaev</a>
       </div>
    

    

</div>

</body>
</html>