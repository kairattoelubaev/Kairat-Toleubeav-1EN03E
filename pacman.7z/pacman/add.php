<?php
  $allowedExts = array("gif", "jpeg", "jpg", "png");
  $temp = explode(".", $_FILES["file"]["name"]);
  $extension = end($temp);
    if ((($_FILES["file"]["type"] == "image/gif")
      || ($_FILES["file"]["type"] == "image/jpeg")
      || ($_FILES["file"]["type"] == "image/jpg")
      || ($_FILES["file"]["type"] == "image/pjpeg")
      || ($_FILES["file"]["type"] == "image/x-png")
      || ($_FILES["file"]["type"] == "image/png"))
      && ($_FILES["file"]["size"] < 200000)
      && in_array($extension, $allowedExts))
        {
          if ($_FILES["file"]["error"] > 0)
            {
              echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
            }
            else
              {
                echo "Upload: " . $_FILES["file"]["name"] . "<br>";
                echo "Type: " . $_FILES["file"]["type"] . "<br>";
                echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
                echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br>";

                if (file_exists("uploads/" . $_FILES["file"]["name"]))
                  {
                    echo $_FILES["file"]["name"] . " already exists. ";
                  }
                else
                  {
                    move_uploaded_file($_FILES["file"]["tmp_name"],
                    "uploads/" . $_FILES["file"]["name"]);
                    echo "Stored in: " . "upload/" . $_FILES["file"]["name"] ."<br>";
                    //SQL CONNECTION                    
                    $con=mysqli_connect("localhost","root","","bookstore");
                    // Check connection
                    if (mysqli_connect_errno()){
                        echo "Failed to connect to MySQL: " . mysqli_connect_error();
                      }
                    mysql_set_charset('utf8');
                    $sql = "INSERT INTO book (name,author,page,year,category,pic,details,price,status) VALUES('".$_POST['name']."','".$_POST['author']."','".$_POST['page']."','".$_POST['year']."','".$_POST['category']."','".$_FILES['file']['name']."','".$_POST['details']."','".$_POST['price']."','".$_POST['status']."')";
                    if (!mysqli_query($con,$sql)){
                        die('Error: ' . mysqli_error($con));
                    }
                    mysqli_close($con);            
                  }
               }
        }
    else
    {
      echo "Invalid file";
    }
  header( 'Location: admin.php?pos='.($_POST['pos'] - 1) ) ;
?>